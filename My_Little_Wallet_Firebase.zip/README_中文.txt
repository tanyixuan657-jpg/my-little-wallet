My Little Wallet ♡ — Firebase 连接版

此版本已把你提供的 Firebase Web 配置接入原型，并加入 Email 注册/登录、Google 登录、Firestore 记账记录和储蓄目标同步。

重要：
1. 这是网页应用源码，不是已经上线的 App。需要部署到 HTTPS 网站（例如 Firebase Hosting）后，登录与云端功能才可正常使用。不要直接用 iPhone 的“文件”预览 index.html 测试。
2. Firebase Console → Authentication → Settings → Authorized domains：部署后要加入网站域名。
3. Google 登录在 iPhone Safari 上如弹窗受阻，可再改为 redirect 流程。
4. Apple 登录尚未接入；需在 Firebase Authentication 启用 Apple provider 并配置 Apple Developer 服务。
5. Firestore 规则假设资料路径为 users/{用户UID}/transactions 与 users/{用户UID}/settings/main。
6. 目前代码将本机已有记录在首次登录且云端为空时迁移到云端。若云端已有记录，则以云端记录为准。
7. Firebase Web apiKey 是客户端配置，不是服务帐号私钥；仍应保持 Firestore 安全规则，不要设置成 allow read, write: if true。

部署前建议先在电脑或 Firebase Hosting 测试。
